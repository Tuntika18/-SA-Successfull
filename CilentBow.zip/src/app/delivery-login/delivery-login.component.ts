import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-login',
  templateUrl: './delivery-login.component.html',
  styleUrls: ['./delivery-login.component.css']
})
export class DeliveryLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
